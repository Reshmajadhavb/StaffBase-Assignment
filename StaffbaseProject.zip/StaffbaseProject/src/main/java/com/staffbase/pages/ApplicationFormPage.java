package com.staffbase.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.staffbase.core.CoreMethods;

public class ApplicationFormPage extends CoreMethods {

	WebDriverWait wait;
	String framexpath = "//div[@id='grnhse_app']//iframe";
	String firstNameField = "first_name";
	String lastNameField = "last_name";
	String emailField = "email";
	String phoneField = "phone";
	String dropdownField1 = "//span[@id='select2-chosen-1']";
	String yesOptionSelect = "(//div[@class='select2-result-label'])[2]";
	String visaStatus = "//input[@id='job_application_answers_attributes_0_text_value']";
	String otherInfo = "//textarea[@id='job_application_answers_attributes_2_text_value']";
	String submitButton = "//input[@id='submit_app']";

	String cvfile = "D:\\resume\\ReshmaJadhav_QAProfile.docx";

	public ApplicationFormPage(WebDriver driver,WebDriverWait wait) {
		super(driver);
		this.wait=wait;

		// TODO Auto-generated constructor stub
	}
	public void switchFrame() {
		//WebElement frame1 = driver.findElement(By.xpath("//div[@id='grnhse_app']//iframe"));
		//driver.switchTo().frame(driver.findElement(By.xpath("//div[@id='grnhse_app']//iframe")));
		switchToFrame(framexpath, "xpath");
	}
	public void enterData() throws InterruptedException, AWTException {
		// driver.findElement(By.id("first_name")).sendKeys("Reshma");
		sendKeysElement(firstNameField, "id", "Reshma");
		// driver.findElement(By.id("last_name")).sendKeys("Jadhav");
		sendKeysElement(lastNameField, "id", "Jadhav");
		// driver.findElement(By.id("email")).sendKeys("jagtapdakshayani23@gmail.com");
		sendKeysElement(emailField, "id", "jagtapdakshayani23@gmail.com");
		// driver.findElement(By.id("phone")).sendKeys("+4915906779344");
		sendKeysElement(phoneField, "id", "015906779344");
	}

	public void uploadResume() throws InterruptedException, AWTException {

		WebElement uploadresume = driver
				.findElement(By.xpath("//button[@aria-describedby='resume-allowable-file-types']"));

		wait.until(ExpectedConditions.elementToBeClickable(uploadresume));

		uploadresume.click();
		Thread.sleep(3000);
		StringSelection ss = new StringSelection(cvfile);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

		// native key strokes for CTRL, V and ENTER keys
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

	}

	public void textDataMethod() throws InterruptedException {
		
		sendKeysElement(visaStatus, "xpath", "Currently i have dependent visa with work permit");
		
		// driver.findElement(By.xpath("//span[@id='select2-chosen-1']")).click();
		
		clickElementBy(dropdownField1, "xpath");
		// driver.findElement(By.xpath("(//div[@class='select2-result-label'])[2]")).click();
		//Thread.sleep(2000);
		clickElementBy(yesOptionSelect, "xpath");
		// driver.findElement(By.xpath("//input[@id='job_application_answers_attributes_0_text_value']")).sendKeys("Currently
		// i have dependent visa with work permit");
		// driver.findElement(By.cssSelector("#job_application_answers_attributes_2_text_value")).sendKeys("https://github.com/");
		sendKeysElement(otherInfo, "xpath", "https://github.com/");
	}

	
	  public void submitForm() throws InterruptedException { 
	//  driver.findElement(By.xpath("//input[@id='submit_app']")).click();
	  
		  Thread.sleep(2000);
	  clickElementBy(submitButton, "xpath");
	  }
	 
}
