package com.staffbase.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.staffbase.core.CoreMethods;

public class HomePage extends CoreMethods {

	String acceptPopUp = "//button[@id='onetrust-accept-btn-handler']";
	String applyButton = "(//a[text()='Apply'])[1]";

	// public WebDriverWait wait;

	public HomePage(WebDriver driver) {

		super(driver);

	}

	public void clickOnAcceptPopUp() {

		clickElementBy(acceptPopUp, "xpath");
	}

	public void clickOnApplyButton() {

		clickElementBy(applyButton, "xpath");
	}

}
