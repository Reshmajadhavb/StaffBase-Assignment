package com.staffbase.testcases;

import org.testng.annotations.Test;

import com.staffbase.base.ProjectSpecifiedMethods;
import com.staffbase.pages.ApplicationFormPage;
import com.staffbase.pages.HomePage;

public class ApplyToJob extends ProjectSpecifiedMethods {

	HomePage homepage;
	ApplicationFormPage applicationPage;

	@Test
	public void TC_applicationForm() throws Exception {

		homepage = new HomePage(driver);
		homepage.clickOnAcceptPopUp();
		homepage.clickOnApplyButton();
		applicationPage =new ApplicationFormPage(driver, wait);
		applicationPage.switchFrame();
		applicationPage.enterData();
		applicationPage.uploadResume();
		applicationPage.textDataMethod();
		applicationPage.submitForm();


	}

}
