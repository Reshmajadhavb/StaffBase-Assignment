package com.staffbase.core;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CoreMethods {

	public WebDriver driver;
	public WebDriverWait wait;

	public CoreMethods(WebDriver drivercon) {
		driver = drivercon;

	}

	public void clickElementBy(String webelement, String locator) {

		if (driver != null) {
			if (locator.equalsIgnoreCase("xpath")) {
				driver.findElement(By.xpath(webelement)).click();
			} else if (locator.equalsIgnoreCase("id")) {
				driver.findElement(By.id(webelement)).click();
			} else if (locator.equalsIgnoreCase("cssSelector")) {
				driver.findElement(By.cssSelector(webelement)).click();
			}
			
		}
	}

	public void switchToFrame(String webelement, String locator) {

		if (driver != null) {
			if (locator.equalsIgnoreCase("xpath")) {
				driver.switchTo().frame(driver.findElement(By.xpath(webelement)));
			} else if (locator.equalsIgnoreCase("id")) {
				driver.switchTo().frame(driver.findElement(By.xpath(webelement)));

			}
		}

	}

	public void sendKeysElement(String webelement, String locator, String elementValue) {
		if (driver != null) {
			if (locator.equalsIgnoreCase("xpath")) {
				driver.findElement(By.xpath(webelement)).sendKeys(elementValue);
			} else if (locator.equalsIgnoreCase("id")) {
				driver.findElement(By.id(webelement)).sendKeys(elementValue);
			}
		}

	}
}
